/**
 * Clase para mandar los msj de exception
 * 
 * @author Alegre Ariel Santiago
 */
public class ValidarIngresoLibrosException extends Exception{
    public ValidarIngresoLibrosException(String mensaje){
        super(mensaje);
    }
}
  