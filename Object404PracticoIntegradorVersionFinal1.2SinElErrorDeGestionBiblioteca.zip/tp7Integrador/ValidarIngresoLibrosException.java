public class ValidarIngresoLibrosException extends Exception{
    public ValidarIngresoLibrosException(String mensaje){
        super(mensaje);
    }
}
  