/**
 * 
 */
public class ValidarIngresoSocioException extends Exception{
    public ValidarIngresoSocioException(String mensaje){
        super(mensaje);
    }
}