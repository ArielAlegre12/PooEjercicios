public class LibroNoPrestadoException extends Exception {
    
    public LibroNoPrestadoException(String mensaje) {
        super(mensaje);
    }
}
